//
//  HackaTruck_Projeto_GrupoApp.swift
//  HackaTruck_Projeto_Grupo
//
//  Created by Turma02-24 on 03/04/25.
//

import SwiftUI

@main
struct HackaTruck_Projeto_GrupoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
