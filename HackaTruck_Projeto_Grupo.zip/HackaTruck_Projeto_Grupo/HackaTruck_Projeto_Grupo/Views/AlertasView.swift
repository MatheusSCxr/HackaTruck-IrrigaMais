//
//  AlertasView.swift
//  HackaTruck_Projeto_Grupo
//
//  Created by Turma02-24 on 03/04/25.
//

import SwiftUI

struct AlertasView: View {
    var body: some View {
        Text("Não existem alertas ativos.")
    }
}

#Preview {
    AlertasView()
}
